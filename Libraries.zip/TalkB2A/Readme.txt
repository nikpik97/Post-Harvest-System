This libaray is created for the communication between Hub A and Hub B
Project Page: https://github.com/Lramir73/In-The-Bag_Sensor_Hub


Author: Haowen Zhang,  Aug,2016.